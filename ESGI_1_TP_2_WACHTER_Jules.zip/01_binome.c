#include <stdio.h>
#include <stdlib.h>

int main() 
{
    char car;
    int ent;
    car = '4';
    ent = 2;
    
    printf("car vaut : %c\n", car);
    printf("ent vaut : %i\n", ent);
    printf("l'entier de car vaut : %i\n", car);

    exit(EXIT_SUCCESS);
}