#include <stdio.h>
#include <stdlib.h>

int main() 
{
    unsigned long gros_nombre;

//Le type lui permettant d'avoir le plus gros nombre entier non négatif est unsigned long

    printf("Entrez un gros nombre : ");
    scanf("%ld", &gros_nombre);
    printf("%ld, un gros nombre ?\n", gros_nombre);

    gros_nombre = 999999999999999999;

    printf("%X, un gros nombre !\n", gros_nombre);

    exit(EXIT_SUCCESS);
}

//int ne prends que 4 octects, ce qui limite donc sa valeur, long quand à lui peut prendre jusqu'à 8 octets.