#include <stdio.h>
#include <stdlib.h>

int main() 
{
    unsigned int valeure = 0xfb408be9;
    printf("fb408be9 = %u\n", valeure);

    printf("\n");

    printf("42 en hexadécimal vaut : %X\t", 42);
    printf("42 en décimal vaut : %i\n", 42);

    printf("\n");

    printf("Ces nombre signifient :");
    printf(" if %x", 212063991488173);
    printf(" then %x\n", 223196547513038);

    exit(EXIT_SUCCESS);
}